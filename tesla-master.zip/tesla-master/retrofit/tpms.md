# TPMS

internal.dat: `tpmstype 3`

![](https://i.imgur.com/v3VIdfa.png)

https://static.nhtsa.gov/odi/tsbs/2016/SB-10081828-5448.pdf
