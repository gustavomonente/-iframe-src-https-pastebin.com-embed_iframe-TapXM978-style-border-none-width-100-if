# LTE

```
1054968-01-B PCBA, LTE CONNECTIVITY, UBLOX GPS $8x
1035347-00-A SIM CARD, JASPER, This card is LTE specific
*1011778-01-C PCBA GYRO SENSOR 
*1014006-00-A BRKT, GYRO PCBA
You can reuse your old gyro and bracket, I did...
```

New modem will bolt into same 3 mount points.  Dont worry the 2 for the side gyro is in different spot.  MAKE sure you connect GPS antenna on connector labeled GPS.  Once again dont ask me why I know this.  You will need to remove 18 screws, 12 T-25 that secure screen to chassis, and 6 T-20 that secure trim to mcu.  I flipped the trim around as I opened so I didn't have to cut the zip tie for bluetooth antenna.  I later realized you can pry the antenna off and clip it back when your finished.  Not removing the bluetooth antenna makes it a little harder to change the modem, have a helper steady the MCU or prop it with things.  Then put back in car and good to go.
