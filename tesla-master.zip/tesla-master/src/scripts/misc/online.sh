mv /home/tesla/.Tesla/car/cell_apn.bak /home/tesla/.Tesla/car/cell_apn
emit-reboot-gateway
