# Dump your settings

This will present two links to Termbin in the format of those files that you see in the dumps folders on Github

## Install

```bash
bash <(curl -sL "https://raw.githubusercontent.com/Lunars/tesla/master/dumps/dump.sh")
```

## Usage

Optional argument `raw` to allow sensitive information in the dump

```bash
bash ./dump.sh raw
```
