Intended to hold the mxd's for any map services that are specific to this app.
