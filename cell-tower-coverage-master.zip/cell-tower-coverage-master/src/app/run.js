(function () {
    require({baseUrl: './'}, ['dojo/parser', 'jquery', 'dojo/domReady!'], function (parser) {
        parser.parse();
    });
}());
