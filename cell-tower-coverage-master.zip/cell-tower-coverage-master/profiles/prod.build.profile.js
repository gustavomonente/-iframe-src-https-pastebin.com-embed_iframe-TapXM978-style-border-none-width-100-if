/*eslint-disable no-unused-vars*/
var profile = {
    staticHasFeatures: {
        'agrc-build': '"prod"'
    }
};
