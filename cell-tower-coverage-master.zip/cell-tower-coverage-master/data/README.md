Intended to hold any data that you want included and version with the app.
