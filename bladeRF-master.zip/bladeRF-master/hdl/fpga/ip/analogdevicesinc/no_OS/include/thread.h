#ifndef BLADERF_THREAD_H_
#define BLADERF_THREAD_H_

/* Stub out MUTEX, since we don't really use anything else pthread here */
#define MUTEX bool

#endif
