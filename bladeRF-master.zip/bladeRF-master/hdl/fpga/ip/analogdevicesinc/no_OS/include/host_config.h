#ifndef HOST_CONFIG_H__
#define HOST_CONFIG_H__

#include <unistd.h>

#define ARRAY_SIZE(n) (sizeof(n) / sizeof(n[0]))

#endif
