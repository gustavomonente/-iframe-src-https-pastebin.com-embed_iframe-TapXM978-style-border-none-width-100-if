This bootloader is based on the non-secure one in the SDK version 11.0.0_89a8197. It still has some dependency/code that is dropped in the later sdk
