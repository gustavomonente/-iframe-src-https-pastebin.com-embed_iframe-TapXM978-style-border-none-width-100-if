SDK version is 14.2.0_17b948a
