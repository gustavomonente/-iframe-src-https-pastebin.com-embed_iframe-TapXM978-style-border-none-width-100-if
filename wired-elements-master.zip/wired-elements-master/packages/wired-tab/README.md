![wired tabs](https://wiredjs.github.io/wired-elements/images/tabs.png)

# wired-tabs
Hand-drawn sketchy Tabs web component.

For demo and view the complete set of wired-elememts: [wiredjs.com](http://wiredjs.com/)
