# wired-item

wired-item is a list item used by Wired components like wired-combo and wired-list-box

[wiredjs.com](https://wiredjs.com)

## License
[MIT License](https://github.com/wiredjs/wired-elements/blob/master/LICENSE) (c) [Preet Shihn](https://twitter.com/preetster)