# wired-lib

This is the core rendering library used by all wired ui components.

[wiredjs.com](https://wiredjs.com)

## License
[MIT License](https://github.com/wiredjs/wired-elements/blob/master/LICENSE) (c) [Preet Shihn](https://twitter.com/preetster)