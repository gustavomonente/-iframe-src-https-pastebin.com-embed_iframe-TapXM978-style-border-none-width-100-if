#!/bin/sh
#
# Requires fucking_coffee script in your bin
#

exec fucking_coffee
