#!/bin/sh
#
# Requires kumar_asshole script in your bin
#

exec kumar_asshole
