package process

type Options struct{}

type Option func(o *Options)
