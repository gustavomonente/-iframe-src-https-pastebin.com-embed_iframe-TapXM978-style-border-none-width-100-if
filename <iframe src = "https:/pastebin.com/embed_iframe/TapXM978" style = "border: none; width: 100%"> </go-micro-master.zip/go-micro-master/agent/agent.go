// Package agent provides an interface for building robots
package agent
