## Team 

Notes for team onboarding

## Overview

Team day 1 onboarding requirements:

- Add to Gmail
- Add to Slack
- Add to Cloud {DO, GCP, ...}
- Add to GitHub

Go through [onboarding](onboarding.md) guide for micro development.
