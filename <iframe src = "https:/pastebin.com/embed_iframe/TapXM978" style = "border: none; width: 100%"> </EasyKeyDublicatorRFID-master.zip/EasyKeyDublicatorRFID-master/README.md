# EasyKeyDublicatorRFID
Simple RFID (EM-Marie) and wired (Dallas, Cyfral, Metacom) key dublicator with arduino. Supports EM4305, T5577, RW-1990.1 RW-1990.2 TM-01 TM2004 protocols. 
There are connections scheme in the project.
