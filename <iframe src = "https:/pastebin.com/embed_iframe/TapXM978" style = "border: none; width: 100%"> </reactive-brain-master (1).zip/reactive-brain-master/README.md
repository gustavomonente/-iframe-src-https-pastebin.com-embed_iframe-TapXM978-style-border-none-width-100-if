# reactive-brain

Playground for some implementations of neural networking methods in reactive functional programming style. 
