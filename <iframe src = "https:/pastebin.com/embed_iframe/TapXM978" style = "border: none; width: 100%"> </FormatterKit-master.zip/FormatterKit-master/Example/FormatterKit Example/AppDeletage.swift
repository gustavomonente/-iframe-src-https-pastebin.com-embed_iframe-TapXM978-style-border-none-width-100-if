//
//  AppDeletage.swift
//  FormatterKit Example
//
//  Created by Victor Ilyukevich on 2/7/16.
//  Copyright © 2016. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDeletage: UIResponder {
    var window: UIWindow?
}

extension AppDeletage: UIApplicationDelegate {
}
