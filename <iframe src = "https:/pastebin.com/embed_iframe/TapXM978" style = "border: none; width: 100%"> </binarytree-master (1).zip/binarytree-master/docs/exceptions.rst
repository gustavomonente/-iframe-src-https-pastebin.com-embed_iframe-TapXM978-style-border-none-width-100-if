Exceptions
----------

The page lists the exceptions raised by **binarytree**:

.. automodule:: binarytree.exceptions
    :members:
