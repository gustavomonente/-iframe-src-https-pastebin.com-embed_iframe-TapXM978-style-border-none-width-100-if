# Changelog
All notable changes to this project will be documented in this file.

## [1.0.8] - 2019-12-27
### Added
- Migration to androidx


## [1.0.6] - 2019-09-02
### Added
- Add auto clean up mechanism.
