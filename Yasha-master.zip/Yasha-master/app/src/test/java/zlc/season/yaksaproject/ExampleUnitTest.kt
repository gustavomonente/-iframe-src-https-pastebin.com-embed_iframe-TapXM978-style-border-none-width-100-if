package zlc.season.yaksaproject

import org.junit.Test

import org.junit.Assert.*

/**
 * Example local unit builderMap, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }
}
