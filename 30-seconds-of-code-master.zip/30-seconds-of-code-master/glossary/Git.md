---
title: Git
tags: Git
---

Git is an open-source version control system, used for source code management.
Git allows users to copy (clone) and edit code on their local machines, before merging it into the main code base (master repository).
