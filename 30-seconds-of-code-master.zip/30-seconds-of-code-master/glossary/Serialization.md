---
title: Serialization
tags: Serialization
---

Serialization is the process of converting an object or data structure into a format suitable for transfer over a network and/or storage.
A common type of serialization in JavaScript is the conversion of an object into a JSON string.
