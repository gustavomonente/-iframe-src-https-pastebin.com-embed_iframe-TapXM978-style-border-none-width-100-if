---
title: Deserialization
tags: Deserialization
---

Deserialization is the process of converting a format that has been transferred over a network and/or used for storage to an object or data structure.
A common type of deserialization in JavaScript is the conversion of JSON string into an object.
