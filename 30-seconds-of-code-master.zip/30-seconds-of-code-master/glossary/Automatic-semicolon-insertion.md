---
title: Automatic semicolon insertion
tags: Automatic semicolon insertion
---

Automatic semicolon insertion (ASI) is a JavaScript feature that allows developers to omit semicolons in their code.
