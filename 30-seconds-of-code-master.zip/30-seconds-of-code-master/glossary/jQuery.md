---
title: jQuery
tags: jQuery
---

jQuery is a frontend JavaScript library, that simplifies DOM manipulation, AJAX calls and Event handling.
jQuery uses its globally defined function, `$()`, to select and manipulate DOM elements.
