---
title: SQL
tags: SQL
---

SQL stands for Structured Query Language and is a language used to create, update, retrieve and calculate data in table-based databases.
SQL databases use a relational database model and are particularly useful in handlind structured data with relations between different entities.
