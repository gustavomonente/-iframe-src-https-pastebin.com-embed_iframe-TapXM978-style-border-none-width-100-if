---
title: Pseudo-class
tags: Pseudo-class
---

In CSS, a pseudo-class is used to define a special state of an element and can be used as a selector in combination with an id, element or class selector.
