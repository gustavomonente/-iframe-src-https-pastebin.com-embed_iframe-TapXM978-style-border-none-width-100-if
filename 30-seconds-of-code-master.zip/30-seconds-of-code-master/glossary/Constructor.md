---
title: Constructor
tags: Constructor
---

In class-based object-oriented programming, a constructor is a special type of function called to instantiate an object.
Constructors often accept arguments that are commonly used to set member properties.
