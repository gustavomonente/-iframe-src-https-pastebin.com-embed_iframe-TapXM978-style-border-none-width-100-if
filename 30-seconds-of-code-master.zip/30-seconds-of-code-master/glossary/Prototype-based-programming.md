---
title: Prototype-based programming
tags: Prototype-based programming
---

Prototype-based programming is a style of object-oriented programming, where inheritance is based on object delegation, reusing objects that serve as prototypes.
Prototype-based programming allows the creation of objects before defining their classes.
