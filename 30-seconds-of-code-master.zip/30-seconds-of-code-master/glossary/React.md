---
title: React
tags: React
---

React is a frontend framework, that allows developers to create dynamic, component-based user interfaces.
React separates view and state, utilizing a virtual DOM to update the user interface.
