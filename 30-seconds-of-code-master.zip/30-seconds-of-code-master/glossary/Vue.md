---
title: Vue
tags: Vue
---

Vue.js is a progressive frontend framework for building user interfaces.
Vue.js separates view and state, utilizing a virtual DOM to update the user interface.
