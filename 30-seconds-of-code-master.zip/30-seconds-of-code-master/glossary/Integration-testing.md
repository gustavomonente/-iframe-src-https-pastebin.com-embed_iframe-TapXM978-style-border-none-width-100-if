---
title: Integration testing
tags: Integration testing
---

Integration testing is a type of software testing, used to test groups of units/components of a software.
The purpose of integration tests are to validate that the units/components interact with each other as expected.
