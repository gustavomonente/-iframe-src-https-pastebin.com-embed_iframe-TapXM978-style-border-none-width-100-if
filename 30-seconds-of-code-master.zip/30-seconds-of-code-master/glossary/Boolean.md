---
title: Boolean
tags: Boolean
---

Booleans are one of the primitive data types in JavaScript. 
They represent logical data values and can only be `true` or `false`.
