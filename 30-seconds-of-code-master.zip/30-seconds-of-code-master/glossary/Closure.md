---
title: Closure
tags: Closure
---

A closure is the combination of a function and the lexical environment within which that function was declared.
The closure allows a function to access the contents of that environment.
