---
title: Viewport
tags: Viewport
---

A viewport is a polygonal (usually rectangular) area in computer graphics that is currently being viewed.
In web development and design, it refers to the visible part of the document that is being viewed by the user in the browser window.
