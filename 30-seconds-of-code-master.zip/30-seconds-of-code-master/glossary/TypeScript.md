---
title: TypeScript
tags: TypeScript
---

TypeScript is a superset of JavaScript, adding optional static typing to the language.
TypeScript compiles to plain JavaScript.
