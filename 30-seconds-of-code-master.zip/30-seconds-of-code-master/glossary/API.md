---
title: API
tags: API
---

API stands for Application Programming Interface and is a set of features and rules provided by a provided by a software to enable third-party software to interact with it.
The code features of a web API usually include methods, properties, events or URLs.
