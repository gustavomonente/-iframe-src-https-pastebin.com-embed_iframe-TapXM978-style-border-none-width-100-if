---
title: Factory functions
tags: Factory functions
---

In JavaScript, a factory function is any function, which is not a class or constructor, that returns a new object.
Factory functions don't require the use of the `new` keyword.
