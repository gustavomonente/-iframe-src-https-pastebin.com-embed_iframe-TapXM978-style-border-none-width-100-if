#!/bin/bash
echo 
tcpick -C -v -a -h "not port 22" -F1 -F2 -yP  -c1
