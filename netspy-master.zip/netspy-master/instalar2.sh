#!/bin/bash
echo
echo "instalando go ..."
sudo apt-get install golang
echo "instalando bettercap ..."
sudo apt-get install bettercap
echo "fin"
