#!/bin/bash
echo 
tcpick  -C -h "not port 22" -a --separator -t -v -yX
