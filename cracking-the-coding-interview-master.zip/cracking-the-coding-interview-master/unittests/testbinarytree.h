#ifndef TESTBINARYTREE_H
#define TESTBINARYTREE_H

void testBinaryTree();

#endif // TESTBINARYTREE_H
