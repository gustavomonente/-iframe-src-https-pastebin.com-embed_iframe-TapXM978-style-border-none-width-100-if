#ifndef TESTSTACK_H
#define TESTSTACK_H

void testStack();

#endif
