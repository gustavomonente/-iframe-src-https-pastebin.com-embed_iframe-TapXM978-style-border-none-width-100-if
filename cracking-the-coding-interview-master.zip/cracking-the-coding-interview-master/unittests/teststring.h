#ifndef TESTSTRING_H
#define TESTSTRING_H

void teststring();

#endif // TESTSTRING_H
