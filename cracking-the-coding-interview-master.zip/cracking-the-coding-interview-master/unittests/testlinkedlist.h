#ifndef _TESTLINKEDLIST_H
#define _TESTLINKEDLIST_H

void testLinkedList();

#endif
