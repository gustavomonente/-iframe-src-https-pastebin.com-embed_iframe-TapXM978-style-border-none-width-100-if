/*
 * demonstrate a real world use of std::multiset
 */

void test12_x_0()
{

}
