# SPARQL 1.2 Community Group

Welcome to the [SPARQL 1.2 Community Group](https://www.w3.org/community/sparql-12/) github repository.

[Mailing list archive](https://lists.w3.org/Archives/Public/public-sparql-12/).

