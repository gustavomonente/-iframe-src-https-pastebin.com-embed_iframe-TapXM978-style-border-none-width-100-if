---
name: New feature
about: Suggest an idea for SPARQL 1.2
title: ''
labels: ''
assignees: ''

---

<!--Please fill in the following template and make sure your title is clear and concisely summarizes the feature.-->

## Why?

<!--Please give a description of why you would like this.-->

## Previous work

<!--Links to resources that implement a solution (or part of).-->

## Proposed solution

<!--A straw man example to give it something tangible and for illustrative purposes.-->

## Considerations for backward compatibility

<!--Can you see any issues with backwards compatibility, no matter how remote.-->
