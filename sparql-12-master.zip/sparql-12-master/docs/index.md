---
layout: null
title: SPARQL 1.2 Community Group
---
This is the github pages home for the "[SPARQL 1.2 Community Group](https://www.w3.org/community/sparql-12/)"

[Github respository](https://githuib.com/w3c/sparql12/)
