from django.apps import AppConfig


class DataeditConfig(AppConfig):
    name = "dataedit"
