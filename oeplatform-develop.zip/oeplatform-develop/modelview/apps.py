from django.apps import AppConfig


class ModelviewConfig(AppConfig):
    name = "modelview"
