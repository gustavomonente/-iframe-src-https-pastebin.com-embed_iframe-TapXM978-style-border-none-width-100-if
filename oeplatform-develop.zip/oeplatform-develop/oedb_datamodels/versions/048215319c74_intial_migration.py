"""Intial migration

Revision ID: 048215319c74
Revises: 
Create Date: 2017-09-18 19:09:05.672967

"""
import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision = "048215319c74"
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
