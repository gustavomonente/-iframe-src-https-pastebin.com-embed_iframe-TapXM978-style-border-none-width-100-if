from django.apps import AppConfig


class LiteratureConfig(AppConfig):
    name = "literature"
