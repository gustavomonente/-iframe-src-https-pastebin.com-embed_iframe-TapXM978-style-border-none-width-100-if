======================
Database visualisation
======================

.. automodule:: dataedit.views
    :members: