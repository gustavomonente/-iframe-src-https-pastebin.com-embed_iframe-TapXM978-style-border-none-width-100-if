=================
Factsheet handler
=================

.. automodule:: modelview.views
    :members: