// TODO: collapse to config
// https://babeljs.io/docs/setup/#jest
module.exports = require('babel-jest');
