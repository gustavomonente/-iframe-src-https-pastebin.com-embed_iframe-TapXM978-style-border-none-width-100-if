
*As of Autumn 2016, Evennia's development roadmap is tracked through the [Evennia Projects Page](https://github.com/evennia/evennia/projects).*