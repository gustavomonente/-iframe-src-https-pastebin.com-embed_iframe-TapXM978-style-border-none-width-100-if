![http://www.evennia.com](http://tinyurl.com/q6w3ao7) 

**Navigation**

- [[Home]]
- [[Search|https://cse.google.com:443/cse/publicurl?cx=010440404980795145992:h6xl9txbq3i]] / [[Index|Wiki Index]]
- [[Evennia Introduction]]
- [[Get and Give Help|How To Get And Give Help]]
- [[Glossary of terms|Glossary]]

**Sections**

- [[Getting Started]]
- [[Admin Docs|Administrative Docs]]
- [[Builder Docs]]
- [[Developer Central]]
- [[Tutorials & Examples|Tutorials]]
- [[API|evennia]]

**Links**

- [Evennia home](http://www.evennia.com/)
- [Code](https://github.com/evennia/evennia)
- [Discussions](https://groups.google.com/forum/#!forum/evennia)
- [Chat](http://webchat.freenode.net/?channels=evennia&uio=MT1mYWxzZSY5PXRydWUmMTE9MTk1JjEyPXRydWUbb)
- [[Links and Resources|Links]]
