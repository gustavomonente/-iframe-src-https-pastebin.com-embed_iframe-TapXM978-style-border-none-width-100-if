# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.0.0   | :white_check_mark: |
| 0.20.x  | :white_check_mark: |


## Reporting a Vulnerability

Please report any potential security issues to `team@nodered.org`. This will notify the core project team who will respond accordingly.
