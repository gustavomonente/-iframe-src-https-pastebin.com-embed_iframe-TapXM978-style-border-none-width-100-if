Virus.Lolita69
==============

Project that aims to let student teams write their own virus which must not be detected by team self-developped antivirus.