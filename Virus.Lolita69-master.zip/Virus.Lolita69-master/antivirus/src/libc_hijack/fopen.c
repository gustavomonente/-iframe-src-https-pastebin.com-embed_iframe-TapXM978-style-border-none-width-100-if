#include <stdio.h>

FILE* fopen(const char* file, const char* mode)
{
	return stdout;
}
