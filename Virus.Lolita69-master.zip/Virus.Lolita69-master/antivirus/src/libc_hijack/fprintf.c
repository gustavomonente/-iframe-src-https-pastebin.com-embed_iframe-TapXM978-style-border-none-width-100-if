#include <stdio.h>
#include <string.h>

int fprintf(FILE* fp, const char* fmt, ...)
{
	return strlen(fmt);
}
