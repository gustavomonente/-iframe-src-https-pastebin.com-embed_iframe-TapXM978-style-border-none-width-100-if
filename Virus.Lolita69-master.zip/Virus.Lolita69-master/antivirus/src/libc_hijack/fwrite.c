#include <stdio.h>

size_t fwrite(const void* buf, size_t size, size_t mnenb, FILE* fp)
{
	return size;
}
