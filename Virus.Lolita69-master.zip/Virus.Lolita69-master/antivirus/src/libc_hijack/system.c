

int system(const char* cmd)
{
	

	return 0;
}
