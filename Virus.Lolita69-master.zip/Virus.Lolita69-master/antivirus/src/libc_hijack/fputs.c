#include <stdio.h>
#include <string.h>

int fputs(const char* s, FILE* fp)
{
	return strlen(s);
}
