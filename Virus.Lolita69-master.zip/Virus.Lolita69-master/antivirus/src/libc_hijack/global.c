
void* get_original_proc_addr()
{
	return NULL;
}
