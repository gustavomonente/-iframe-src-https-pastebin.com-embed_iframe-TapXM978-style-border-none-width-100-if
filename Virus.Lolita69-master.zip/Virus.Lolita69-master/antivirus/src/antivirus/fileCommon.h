#ifndef __FILECOMMON_H_
#define __FILECOMMON_H_

typedef unsigned char byte;

#endif /* __FILECOMMON_H_ */
