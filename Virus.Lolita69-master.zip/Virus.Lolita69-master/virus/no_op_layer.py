# -*- coding: utf-8 -*-


def a(c):
    return c


DECRYPT = """
def b(c):
    return c
"""
