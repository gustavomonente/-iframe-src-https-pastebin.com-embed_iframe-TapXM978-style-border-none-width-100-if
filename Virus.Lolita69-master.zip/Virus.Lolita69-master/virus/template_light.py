____ = "\xFF\xFE\x0A\x20\xCA\xDD"
# -*- coding: utf-8 -*-

a = "ma"
q = "ad"
d = "lo"
l = "op"
b = None
__DECRYPT_PLACEHOLDER__
u = "rs"
t = "rq"
e = "s"
c = "hal"

x = __import__(a + u + c)

# exec
exec getattr(x, d + q + e)(b("__PAYLOAD_PLACEHOLDER__"))

____ = "\xFF\xFE\x0A\x20\xCA\xDD"
