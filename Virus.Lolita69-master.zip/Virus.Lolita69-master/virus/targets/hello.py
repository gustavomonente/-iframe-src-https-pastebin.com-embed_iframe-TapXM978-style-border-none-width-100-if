print "Bonjour :)"
