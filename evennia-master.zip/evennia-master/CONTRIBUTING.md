# Contributing to Evennia

Evennia utilizes GitHub for issue tracking and contributions:

  - Reporting Issues issues/bugs and making feature requests can be done [in the issue tracker](https://github.com/evennia/evennia/issues).
  - Evennia's documentation is a [wiki](https://github.com/evennia/evennia/wiki) that everyone can contribute to. Further
    instructions and details about contributing is found [here](https://github.com/evennia/evennia/wiki/Contributing).
