"""
This sub-package holds the web presence of Evennia, using normal
Django to relate the database contents to web pages. Also the basic
webclient and the website are defined in here (the webserver itself is
found under the `server` package).
"""
