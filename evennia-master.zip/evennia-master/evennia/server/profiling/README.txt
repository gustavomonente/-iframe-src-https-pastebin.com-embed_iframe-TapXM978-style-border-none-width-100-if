
Dummyrunner

This is a test system for stress-testing the server. It will launch numbers
of "dummy players" to connect to the server and do various sequences of actions.
See header of dummyrunner.py for usage.
