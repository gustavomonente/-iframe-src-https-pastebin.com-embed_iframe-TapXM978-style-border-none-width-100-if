"""
This sub-package holds the template for creating a new game folder.
The new game folder (when running evennia --init) is a copy of this
folder.

"""
