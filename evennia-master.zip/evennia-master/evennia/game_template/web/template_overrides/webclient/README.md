Replace Evennia's webclient django templates with your own here.

You can find the original files in `evennia/web/webclient/templates/webclient/`
