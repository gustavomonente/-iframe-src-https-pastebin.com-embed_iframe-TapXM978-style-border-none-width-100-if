Place your own version of templates into this file to override the default ones.
For instance, if there's a template at: `evennia/web/website/templates/website/index.html`
and you want to replace it, create the file `template_overrides/website/index.html`
and it will be loaded instead.
