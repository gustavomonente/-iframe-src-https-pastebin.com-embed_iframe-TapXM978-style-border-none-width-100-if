The templates involving login/logout can be overwritten here.

You can find the original files in `evennia/web/website/templates/website/registration/`
