"""
This sub-package defines the out-of-character entities known as
Accounts.  These are equivalent to 'accounts' and can puppet one or
more Objects depending on settings. An Account has no in-game existence.

"""
