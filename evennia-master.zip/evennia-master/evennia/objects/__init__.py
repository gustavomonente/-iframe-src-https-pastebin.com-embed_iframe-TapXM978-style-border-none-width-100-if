"""
This sub-package defines the basic in-game "Object". All in-game
objects inherit from classes in this package.

"""
