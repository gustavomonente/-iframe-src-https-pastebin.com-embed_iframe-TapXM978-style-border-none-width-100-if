# -*- coding: utf-8 -*-
"""
This package holds the demo game of Evennia.
"""


from . import mob, objects, rooms
