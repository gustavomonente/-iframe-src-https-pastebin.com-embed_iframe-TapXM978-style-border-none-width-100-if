#### Brief summary of issue / Description of requested feature:


#### Steps to reproduce the issue / Reasons for adding feature:

1. 
2. 
3. 

#### Error output / Expected result of feature


#### Extra information, such as Evennia revision/repo/branch, operating system and ideas for how to solve / implement:
