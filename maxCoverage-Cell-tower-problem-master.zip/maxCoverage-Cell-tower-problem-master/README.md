# maxCoverage-cell-tower-problem-C-
cell tower problem | C++  |dynamic programming implementation

// you are given a list of town populations ( 1 population number for each town)
// you can build cell towers in any town as long as dont build towers in adjacent towns
// max number of people you can cover ? how you cover them (in which towns do you build towers [..])
