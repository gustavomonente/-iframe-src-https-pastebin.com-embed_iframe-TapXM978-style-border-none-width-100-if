# ELF-infection

Reference : Learning Linux Binary Analysis

# BindTCP / ReverseTCP

Reference : https://rastating.github.io/creating-a-reverse-tcp-shellcode/

Reference : https://rastating.github.io/creating-a-bind-shell-tcp-shellcode/

# Dynamic resolver(ptrace)

Reference : http://phrack.org/issues/59/8.html#article

# .so injection(ptrace)

Reference : https://github.com/jmpews/evilELF/tree/17e141012faeebf707e3f9787dbbfb1d26bba3d3
