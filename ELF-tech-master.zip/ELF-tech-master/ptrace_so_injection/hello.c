#include<stdio.h>

int main()
{
	while(1)
	{
		printf("hello !\n");
		sleep(2);
	}
	return 0;
}
