#include<stdio.h>

int main()
{
	int a;
	puts("Hi Dynamic resolver !!");
	scanf("%d",a);

	return 0;
}
