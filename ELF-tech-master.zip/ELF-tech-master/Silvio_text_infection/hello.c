void main()
{
	write(0,"aaaa\n",5);
}
