# WiFI-Virus

Open Text File

Saved As .txt to .bat 
