## Contributing to the Specification for Hack

We'd love your help in improving, correcting, adding to the specification.
Please [file an issue](https://github.com/hhvm/hack-langspec/issues/) or submit a 
pull request at the [spec git repo](https://github.com/hhvm/hack-langspec).

## License for your Contributions

Any contribution you provide to the Specification for Hack must adhere to the
same license as stated in the [LICENSE](LICENSE).
