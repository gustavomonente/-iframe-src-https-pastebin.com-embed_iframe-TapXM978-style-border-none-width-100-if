<?hh // strict

namespace NS_TestInc;

function f2(): void {
  echo "Inside function " . __FUNCTION__ . "\n";
}
