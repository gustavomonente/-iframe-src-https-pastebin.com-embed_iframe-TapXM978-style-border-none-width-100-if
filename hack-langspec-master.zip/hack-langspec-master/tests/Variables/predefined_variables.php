<?hh // strict

namespace NS_predefined_variables;

function main(): void {
/*
  var_dump($argc);
  var_dump($argv);
  var_dump($_COOKIE);
  var_dump($_ENV);
  var_dump($_FILES);
  var_dump($_GET);
  var_dump($GLOBALS);
  var_dump($_POST);
  var_dump($_REQUEST);
  var_dump($_SERVER);
  var_dump($_SESSION);
*/
}

/* HH_FIXME[1002] call to main in strict*/
main();
