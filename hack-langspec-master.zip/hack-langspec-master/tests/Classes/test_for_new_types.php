<?hh // strict

namespace NS_test_for_new_types;

function main(): void {
//  new \ArithmeticError();
//  new \AssertionError();
  new \Closure();
//  new \DivisionByZeroError();
//  new \Error();
  new \Generator();
//  new \ParseError();
//  new \TypeError();
//  new \Throwable();
}

/* HH_FIXME[1002] call to main in strict*/
main($2);