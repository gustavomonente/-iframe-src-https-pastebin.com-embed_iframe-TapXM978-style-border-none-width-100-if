<?hh // strict

namespace NS_Vehicles;

abstract class Vehicle {
  public abstract function getMaxSpeed(): int;

  // ...
}
