// NOT YET IMPLEMENTED IN THE CHECKER <?hh // strict

namespace NS_combined_comparison;

/*
   +-------------------------------------------------------------+
   | Copyright (c) 2015 Facebook, Inc. (http://www.facebook.com) |
   +-------------------------------------------------------------+
*/

function main(): void {

// Integers

  echo (1 <=> 1) . "\n"; // 0
  echo (1 <=> 2) . "\n"; // -1
  echo (2 <=> 1) . "\n"; // 1

// Floats

  echo (1.5 <=> 1.5) . "\n"; // 0
  echo (1.5 <=> 2.5) . "\n"; // -1
  echo (2.5 <=> 1.5) . "\n"; // 1
 
// Strings

  echo ("a" <=> "a") . "\n"; // 0
  echo ("a" <=> "b") . "\n"; // -1
  echo ("b" <=> "a") . "\n"; // 1
}

/* HH_FIXME[1002] call to main in strict*/
main();
