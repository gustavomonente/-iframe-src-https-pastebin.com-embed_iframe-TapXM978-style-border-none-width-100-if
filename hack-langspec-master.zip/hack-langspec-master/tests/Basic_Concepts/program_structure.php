<?hh // strict

// ?> closing tag not allowed
