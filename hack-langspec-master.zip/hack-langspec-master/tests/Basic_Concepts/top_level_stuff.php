<?hh // strict

namespace NS_top_level_stuff;
use NS2\X;
class C {}
interface I {}
trait T {}
function f1(): void {}

//{ }
//f1();
//if (5 < 10) echo "True\n"; else echo "False\n";
//for ($i = 1; $i <= 5; ++$i) echo "$i = $i\n";
//return;
//declare(encoding = 'ISO-8859-1');
//const MAXIMUM_LENGTH = 1000;
//static $s = 100;
