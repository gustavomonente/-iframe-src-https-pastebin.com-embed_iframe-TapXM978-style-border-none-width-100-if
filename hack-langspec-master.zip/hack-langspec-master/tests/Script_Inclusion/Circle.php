<?hh // strict

namespace NS_Circle;

require_once 'Point.php';

class Circle {
  public function __construct(float $newX, float $newY, float $newR) {
  }

  // ...
}
