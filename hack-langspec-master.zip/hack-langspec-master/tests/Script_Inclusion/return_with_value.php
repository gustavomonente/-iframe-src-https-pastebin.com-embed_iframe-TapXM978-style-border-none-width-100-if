<?hh // strict

// has explicit return value, so when included, that value is returned

// return 987;	// can't have a return statement at the top level
