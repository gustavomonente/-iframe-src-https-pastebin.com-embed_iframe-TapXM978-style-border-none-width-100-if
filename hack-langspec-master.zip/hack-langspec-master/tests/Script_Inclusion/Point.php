<?hh // strict

namespace NS_Point_Script_Inclusion;

class Point {
  public function __construct(float $newX = 0.0, float $newY = 0.0) {
  }
}
