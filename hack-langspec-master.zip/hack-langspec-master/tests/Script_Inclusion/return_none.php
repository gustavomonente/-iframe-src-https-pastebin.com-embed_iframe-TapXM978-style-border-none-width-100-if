<?hh // strict

// no return statement, so when included, int(1) is returned
