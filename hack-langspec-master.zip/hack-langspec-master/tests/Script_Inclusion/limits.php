<?hh // strict

namespace NS_limits;

const int MY_MIN = 10;
const int MY_MAX = 50;
