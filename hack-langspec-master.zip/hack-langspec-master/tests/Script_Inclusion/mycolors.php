<?hh // strict

const int RED = 1;
const int WHITE = 2;
const int BLUE = 3;
