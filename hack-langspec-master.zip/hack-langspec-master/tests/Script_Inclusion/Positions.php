<?hh // strict

namespace NS_Positions;

const int TOP = 1;
const int RIGHT = 2;
const int BOTTOM = 3;
const int LEFT = 3;
