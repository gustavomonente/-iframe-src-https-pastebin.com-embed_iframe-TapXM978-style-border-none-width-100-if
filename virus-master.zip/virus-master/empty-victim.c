#include "victim.h"

const struct virus_victim virus_victim __attribute__((section(".ldata")));
