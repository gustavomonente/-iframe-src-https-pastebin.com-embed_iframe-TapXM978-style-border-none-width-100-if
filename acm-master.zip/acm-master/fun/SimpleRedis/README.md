A Redis-like in-memory database.

Program starts with mode selection:
```
  mode 1 -> cmd line mode.
  mode 2 -> read from a 'input.txt' file.
```
only supports key(string) - value(int) pair

allows ROLLBACK
