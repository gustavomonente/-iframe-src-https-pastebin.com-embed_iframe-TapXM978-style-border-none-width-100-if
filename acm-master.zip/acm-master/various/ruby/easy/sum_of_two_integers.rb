# https://leetcode.com/problems/sum-of-two-integers/description/
# @param {Integer} a
# @param {Integer} b
# @return {Integer}
def get_sum(a, b)
  # later
end

p get_sum(-1, 1)
