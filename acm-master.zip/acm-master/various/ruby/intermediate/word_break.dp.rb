def word_break(s, word_dict)
end

p word_break("leetcode", ["leet", "code"])
