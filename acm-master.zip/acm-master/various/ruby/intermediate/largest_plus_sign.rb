# https://leetcode.com/problems/largest-plus-sign/description/
# @param {Integer} n
# @param {Integer[][]} mines
# @return {Integer}
def order_of_largest_plus_sign(n, mines)

end
