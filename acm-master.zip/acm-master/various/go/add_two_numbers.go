package main

import (
  "fmt"
)

// https://leetcode.com/problems/add-two-numbers/description/

type ListNode struct {
  Val int
  Next *ListNode
}

func addTwoNumbers(l1 *ListNode, l2 *ListNode) *ListNode {
}

func main() {
  res := addTwoNumbers()
  fmt.Println(res)
}
