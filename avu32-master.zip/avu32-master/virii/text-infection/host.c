#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main(void)
{
	printf("host\n");
	exit((int)0);
}
