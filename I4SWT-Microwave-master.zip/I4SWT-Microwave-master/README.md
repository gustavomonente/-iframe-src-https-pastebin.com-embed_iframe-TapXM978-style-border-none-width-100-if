# I4SWT-Microwave
Microwave Oven - **I4SWT Mandatory exercise** *(handin 3)*
