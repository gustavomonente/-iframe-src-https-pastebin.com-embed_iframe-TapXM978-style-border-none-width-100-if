﻿namespace Microwave.Core.Interfaces
{
    public interface ILight
    {
        void TurnOn();
        void TurnOff();
    }
}
