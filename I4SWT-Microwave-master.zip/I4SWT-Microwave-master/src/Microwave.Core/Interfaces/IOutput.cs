﻿namespace Microwave.Core.Interfaces
{
    public interface IOutput
    {
        void OutputLine(string line);
    }
}
