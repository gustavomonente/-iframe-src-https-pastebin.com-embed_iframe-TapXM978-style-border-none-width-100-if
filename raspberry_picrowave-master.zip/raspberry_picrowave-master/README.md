# Raspberry Pi-crowave

I put a Raspberry Pi in my microwave.

Now my microwave has:

* Re-designed UI
* Nicer sound effects
* Clock is automatically updated from the internet
* Voice control
* Barcode-scanner to look up cooking instructions
* Online database of cooking instructions at http://www.microwavecookingdb.com
* Web page so you can control the microwave from your phone, and set up cooking instructions for products
* Tweets after finished cooking
