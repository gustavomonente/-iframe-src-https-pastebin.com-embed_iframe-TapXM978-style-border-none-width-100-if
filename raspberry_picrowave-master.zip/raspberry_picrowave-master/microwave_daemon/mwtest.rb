require './microwave'
@m = MicrowaveExt.new
