CIH (Chernobyl)
===

CIH (also known as Chernobyl) was created in 1998 by Chen Ing-hau, a student at Tatung University in Taiwan. It affects only older Windows 9x (95, 98, Me) operating systems.

## This program and its source files are only for educational purposes. Do not execute this program if you don't know what it does

#### References

- [CIH (computer virus) - Wikipedia](http://en.wikipedia.org/wiki/CIH_\(computer_virus\))
- [CIH Virus - Computer Hope](http://www.computerhope.com/vcih.htm)
