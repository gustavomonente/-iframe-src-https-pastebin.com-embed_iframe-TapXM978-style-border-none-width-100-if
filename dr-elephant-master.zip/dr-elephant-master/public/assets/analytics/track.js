/*
  Paste the tracking javascript snippet into this file for web analytics.
  This javascript file will be included into every page in the application.
  See comments section above 'enable.analytics' in the application.conf file for
  more information.
*/