# Simple Linux ELF Virus

A simple virus written in C that infects ELF binaries in linux. This is a course projects and is for academic use only and does not infect anything important in the system.

Future Work:
- Find targets in other folders of the system recursively.
- Decrease the virus file size.
- Use Encryption and Decryptor loop.

Disclaimer: This code is for educational purposes only and was actually for a course project. The code itself cannot be harmful for any system but I am not responsible for any actions taken using this code.
