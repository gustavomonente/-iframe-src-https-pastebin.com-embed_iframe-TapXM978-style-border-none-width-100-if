class NonVirtualClass {
public:
    void foo() {}
};
