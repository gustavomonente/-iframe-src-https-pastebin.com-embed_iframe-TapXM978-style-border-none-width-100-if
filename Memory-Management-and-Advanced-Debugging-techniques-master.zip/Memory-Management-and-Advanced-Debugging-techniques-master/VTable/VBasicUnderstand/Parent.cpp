#include <iostream>
using namespace std;
#pragma once

class Parent {
public:
    virtual void Foo() {}
    virtual void FooNotOverridden() {}
};
