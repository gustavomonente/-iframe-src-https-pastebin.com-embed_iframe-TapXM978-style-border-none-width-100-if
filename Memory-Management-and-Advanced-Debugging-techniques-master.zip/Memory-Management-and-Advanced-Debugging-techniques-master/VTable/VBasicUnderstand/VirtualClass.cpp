class VirtualClass {
private:
public:
    virtual void foo() {}
};

