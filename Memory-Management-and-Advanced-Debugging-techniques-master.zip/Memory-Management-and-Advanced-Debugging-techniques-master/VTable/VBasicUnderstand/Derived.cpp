#include "Parent.cpp"
class Derived : public Parent {
public:
    void Foo() override {}
};

