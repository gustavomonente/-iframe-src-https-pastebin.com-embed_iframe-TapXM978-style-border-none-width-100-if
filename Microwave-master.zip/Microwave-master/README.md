# Domain Modeling Made Functional -- Microwave example

