===============
 API Submodule
===============

.. autofunction:: rfc3986.api.urlparse

.. autofunction:: rfc3986.api.uri_reference

.. autofunction:: rfc3986.api.normalize_uri
