C-ELF-virus
===========

ELF file infector virus which replicated and propagates itself automatically. This was coded in C
