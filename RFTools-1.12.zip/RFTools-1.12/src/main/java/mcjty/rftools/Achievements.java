package mcjty.rftools;

public class Achievements {
//    public static AchievementPage page;
//
//    public static Achievement firstTeleport;
//    public static Achievement hardPower;
//    public static Achievement clearVision;
//    public static Achievement specialOres;
//    public static Achievement theBuilder;
//    public static Achievement goingUp;
//    public static Achievement storeThePower;
//    public static Achievement shieldSafety;
//    public static Achievement allTheItems;

    // @todo

    public static void init() {
//        List<Achievement> achievements = new ArrayList<>();
//
//        firstTeleport = new Achievement("achievement.firstTeleport", "firstTeleport", -2, -2, new ItemStack(TeleporterSetup.matterTransmitterBlock), null).registerStat();
//        achievements.add(firstTeleport);
//
//        hardPower = new Achievement("achievement.hardPower", "hardPower", 0, -2, new ItemStack(EndergenicSetup.endergenicBlock), null).registerStat();
//        achievements.add(hardPower);
//
//        clearVision = new Achievement("achievement.clearVision", "clearVision", 2, -2, new ItemStack(ScreenSetup.screenBlock), null).registerStat();
//        achievements.add(clearVision);
//
//        specialOres = new Achievement("achievement.specialOres", "specialOres", -2, 0, new ItemStack(ModBlocks.dimensionalShardBlock), null).registerStat();
//        achievements.add(specialOres);
//
//        theBuilder = new Achievement("achievement.theBuilder", "theBuilder", 0, 0, new ItemStack(BuilderSetup.builderBlock), null).registerStat();
//        achievements.add(theBuilder);
//
//        goingUp = new Achievement("achievement.goingUp", "goingUp", 2, 0, new ItemStack(ElevatorSetup.elevatorBlock), null).registerStat();
//        achievements.add(goingUp);
//
//        storeThePower = new Achievement("achievement.storeThePower", "storeThePower", -2, 2, new ItemStack(PowerCellSetup.powerCellBlock), null).registerStat();
//        achievements.add(storeThePower);
//
//        shieldSafety = new Achievement("achievement.shieldSafety", "shieldSafety", 0, 2, new ItemStack(ShieldSetup.shieldTemplateBlock), null).registerStat();
//        achievements.add(shieldSafety);
//
//        allTheItems = new Achievement("achievement.allTheItems", "allTheItems", 2, 2, new ItemStack(ModularStorageSetup.storageModuleItem), null).registerStat();
//        achievements.add(allTheItems);
//
//        page = new AchievementPage("RfTools", achievements.toArray(new Achievement[achievements.size()]));
//        AchievementPage.registerAchievementPage(page);
    }

//    public static void trigger(EntityPlayer player, Achievement achievement) {
//        if (achievement.parentAchievement != null) {
//            trigger(player, achievement.parentAchievement);
//        }
//        player.addStat(achievement);
//    }
}
