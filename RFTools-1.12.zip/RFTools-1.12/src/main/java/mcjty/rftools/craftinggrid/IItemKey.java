package mcjty.rftools.craftinggrid;

public interface IItemKey {
}
