package mcjty.rftools.blocks.screens.modulesclient;

import net.minecraft.world.World;

public class ItemStackPlusClientScreenModule extends ItemStackClientScreenModule {
    @Override
    public void mouseClick(World world, int x, int y, boolean clicked) {

    }
}
