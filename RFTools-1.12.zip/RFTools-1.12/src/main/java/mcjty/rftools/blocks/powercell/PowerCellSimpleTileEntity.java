package mcjty.rftools.blocks.powercell;

@SuppressWarnings("EmptyClass")
public class PowerCellSimpleTileEntity extends PowerCellTileEntity {
}
