package mcjty.rftools.blocks.crafter;

public class CrafterBlockTileEntity2 extends CrafterBaseTE {

    public CrafterBlockTileEntity2() {
        super(4);
    }
}
