package mcjty.rftools.blocks.powercell;

@SuppressWarnings("EmptyClass")
public class PowerCellNormalTileEntity extends PowerCellTileEntity {
}
