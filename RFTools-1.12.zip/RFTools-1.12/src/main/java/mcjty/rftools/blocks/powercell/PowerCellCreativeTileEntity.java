package mcjty.rftools.blocks.powercell;

@SuppressWarnings("EmptyClass")
public class PowerCellCreativeTileEntity extends PowerCellTileEntity {
}
