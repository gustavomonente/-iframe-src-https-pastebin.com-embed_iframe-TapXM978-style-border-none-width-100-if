package mcjty.rftools.blocks.powercell;

@SuppressWarnings("EmptyClass")
public class PowerCellAdvancedTileEntity extends PowerCellTileEntity {
}
