package mcjty.rftools.blocks.shield;

@SuppressWarnings("EmptyClass")
public class TickShieldSolidBlockTileEntity extends TickShieldBlockTileEntity {
}
