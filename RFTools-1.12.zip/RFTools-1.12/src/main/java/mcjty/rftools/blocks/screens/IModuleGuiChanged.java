package mcjty.rftools.blocks.screens;

public interface IModuleGuiChanged {
    void updateData();
}
