package mcjty.rftools.blocks.crafter;

public class CrafterBlockTileEntity1 extends CrafterBaseTE {

    public CrafterBlockTileEntity1() {
        super(2);
    }
}
