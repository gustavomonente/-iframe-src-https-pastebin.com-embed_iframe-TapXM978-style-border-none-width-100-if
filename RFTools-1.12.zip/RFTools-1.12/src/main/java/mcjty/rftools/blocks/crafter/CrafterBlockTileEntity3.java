package mcjty.rftools.blocks.crafter;

public class CrafterBlockTileEntity3 extends CrafterBaseTE {

    public CrafterBlockTileEntity3() {
        super(8);
    }
}
