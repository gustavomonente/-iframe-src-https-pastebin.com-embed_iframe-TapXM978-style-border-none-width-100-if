package mcjty.rftools.blocks.screens;

public class CreativeScreenTileEntity extends ScreenTileEntity {
    @Override
    protected boolean isCreative() {
        return true;
    }
}
