package mcjty.rftools.blocks.shield;

@SuppressWarnings("EmptyClass")
public class NoTickShieldSolidBlockTileEntity extends NoTickShieldBlockTileEntity {
}
