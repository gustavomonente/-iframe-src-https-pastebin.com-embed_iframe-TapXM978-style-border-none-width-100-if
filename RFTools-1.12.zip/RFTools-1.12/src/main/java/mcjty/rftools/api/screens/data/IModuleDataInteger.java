package mcjty.rftools.api.screens.data;

/**
 * An integer.
 */
public interface IModuleDataInteger extends IModuleData {
    int get();
}
