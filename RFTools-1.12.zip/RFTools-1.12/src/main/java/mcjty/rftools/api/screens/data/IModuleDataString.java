package mcjty.rftools.api.screens.data;

/**
 * A string.
 */
public interface IModuleDataString extends IModuleData {
    String get();
}
