package mcjty.rftools.api.screens.data;

public interface IModuleDataBoolean extends IModuleData {
    boolean get();
}
